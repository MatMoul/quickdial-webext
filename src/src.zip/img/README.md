# About Image licence :

These images provide from fast dial extention : http://www.userlogos.org/extensions/fastdial
