# About Image licence :
These images provide from fast dial extention but it's only temporary.
I would make my own to be free of all dependencies.
